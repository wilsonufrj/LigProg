#ifndef PRINCIPAIS_H
#define PRINCIPAIS_H

#include"Catalogo.h"
#include<fstream>
#include<iostream>
#include<string>



void AdicionaFilme(Catalogo&);
void RemoveFilme(Catalogo&);
void EditaFilme(Catalogo&);
void MostraCatalogo(Catalogo&);
void MostraFilmeCatalogo(Catalogo&);
void melhorFilme(Catalogo&);


#endif