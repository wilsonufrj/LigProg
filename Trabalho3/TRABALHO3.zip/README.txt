Para compilar o programa basta usar o comando make.
Para executar o programa basta usar o comando make rodar.
E para excluir o executavel e todo o arquivo .o basta usar o comando make clear


--------USO DO PROGRAMA-----
Quando o programa pedir para o usuario escolher uma opção, a entrada deve ser apenas números
Quando o programa pedir um nome, esse nome deve ser uma única palavra, sem o uso de espaços ou acentos
As notas atribuidas a cada filme podem ser qualquer uma desde que seja número
Na edição de um filme os nomes produtora e filme precisam ser escritos com letra maiúscula

