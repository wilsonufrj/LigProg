Para compilar o código basta executar o comando make
Para a execucao basta digitar make rodar ou digitar ./main após a compilação

Para o uso do programa é necessario a criação de um banco de dados no MySQL com o nome 
de "projetoFinal2" e uma tabela com o nome "PRODUTO", para isso basta executar os comandos abaixo
em um shell do mySQL, pelo terminal do Linux ou de qualquer outra distribuição.

Criar database
"CREATE DATABASE projetoFinal2"

Criar Tabela 
"CREATE TABLE PRODUTO"

Com isso a estrutura do banco de dados necessária para o bom funcionamento do gerenciador 
estará pronta. Vale ressaltar que algumas dependencia como o sql-server precisão ser instaladas
para o reconhecimentos das bibliotecas usadas. 

No que se refere ao modo de execução do programa a funcao busca coleção apresentada na primeira entrega
do trabalho final, esta com uma pequena modificacao, após a exibicao das coleções de cada estacao
o usuario deverá digitar as caracteristicas como o nome da coleção, o ano e a estação em 
3 linhas diferentes para a realizacao da busca detalhada, diferente de como foi proposto no relatório.
Ao demais, as entradas quando sugeridas a inserção de números, todos os números podem ser postos e
cada um terá sua devida resposta de acordo com o programado.As casas decimais do preço dos produtos são incluidas
a partir do numero principal seguido de um ponto.

Concluindo, seguindo as devidas orientações o programa funcionará sem nenhum erro não esperado.

Link dos Vídeos apresentando o programa:

Funcionameto do programa gerenciador: https://youtu.be/_eMwjl7OVEo
Funcionamento Makefile: https://youtu.be/R1PBby75bKM
