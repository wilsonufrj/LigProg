#ifndef  DADOS_H
#define DADOS_H

const int DIAS_VERIFICADOS = 10;
const int QUANTIDADE_ESTADO = 4;

const int RIO[] = {1,2,1,3,13,1,5,5,2,2};
const int SAO_PAULO[] = {2,2,2,2,2,2,5,2,5,8};
const int MINAS_GERAIS[] = {3,3,3,3,3,3,3,3,3,3};
const int CEARA[] = {232,1,23,12,4,23,4,2,1,2};


#endif