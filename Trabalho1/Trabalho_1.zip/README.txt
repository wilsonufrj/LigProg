## Instrução para a execução do programa
1) Apos descompartar o arquivo basta executar o comando make na linha de comando
2) Para executar bastar digitar make rodar
3) Para limpar os arquivos gerados na compilação basta digitar make clean